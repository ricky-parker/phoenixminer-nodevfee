PhoenixMiner 5.1c NoDevfee (c) RP.
**********************************

Run the miner as usual, devfee is completely disabled.

--------------------------------------------------------------------------------------------
Virustotal report for nodevfee.dll shows some detects because .dll is packed with protector:
https://www.virustotal.com/gui/file/db4ad25b0b4e870eb1bc2ac5f00292cea8f3fd74774837bff4b2bf180c4b14f3/detection

For comparison see virusotal report for phoenixminer.exe from devs:
https://www.virustotal.com/gui/file/cf407f08781291b9470743ddee1a4136a3470efa388ea617c487cce75c0f2a5e/detection

-------------------------------
For updates and feedback visit:
https://github.com/ricky-parker/phoenixminer-nodevfee

-----------------------------------------
If you want to support me, donate ETH to:
0xf5c3d86379c1ca50994Cd4300D3B20F3E2C8e33a
